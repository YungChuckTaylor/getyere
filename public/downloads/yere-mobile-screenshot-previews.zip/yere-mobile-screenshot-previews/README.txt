YERE — MOBILE SCREENSHOT PREVIEWS

Six PNG images, each 1080 x 1920 pixels (portrait 9:16).
Rendered directly from the existing shared Yere interface in Chromium, using a
432 x 768 CSS-pixel mobile viewport at 2.5x device scale and the app's Plus Jakarta
Sans font. No AI-generated app screens or promotional overlays were used.

IMPORTANT: These are browser-rendered previews, NOT captures from an installed
Android APK, an Android emulator or the signed Play release. Compare them with
the exact Android build being submitted. Only use store images that accurately
represent that build. Native system bars, permission dialogs, keyboard, insets,
WebView rendering and any older release UI may differ.

The browser-only demo uses fictional sample reminders and a fictional profile.
No live accounts, real contacts, tokens or customer data were used. External
backend requests were blocked; no production data was written. Notification
delivery, cloud sync and secure contact sharing were not demonstrated or verified.

FILES
01-home-preview.png             Home workspace summary (scrolled view)
02-week-ahead-preview.png       Upcoming reminders with natural-language input
03-calendar-preview.png         Monthly calendar (scrolled view)
04-recurring-preview.png        Recurring reminders
05-reminder-notes-preview.png   Reminder notes and available actions
06-dark-theme-preview.png      Upcoming reminders in dark mode

Suggested first store image, if it matches your release: 02-week-ahead-preview.png.
Upload only PNG images under Phone screenshots; do not upload this README or ZIP.
The ZIP is a convenient download package to extract on your computer.

For exact Android captures: install the intended Play test build, use fictional
data, and take screenshots with Power + Volume Down (device controls may vary).
Those raw Android screenshots can be resized/packaged separately without inventing
or changing the application's interface.
