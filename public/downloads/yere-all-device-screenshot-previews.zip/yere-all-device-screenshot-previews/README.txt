YERE — ALL-DEVICE STORE SCREENSHOT PREVIEWS

CONTENTS (22 PNG images)
phone/                       6 images, 1080 x 1920, portrait 9:16
 tablet-7-inch/              4 images, 1080 x 1920, portrait 9:16
 tablet-10-inch/             4 images, 2560 x 1440, landscape 16:9
 desktop/                    4 images, 1920 x 1080, landscape 16:9
 xr-flat-format-CANDIDATES/   4 images, 1920 x 1080, landscape 16:9

All images meet the pixel/aspect-ratio/file-size requirements shown in the supplied
Play Console screenshots. Every PNG is below 8 MB (also below the XR 15 MB limit).
Physical screen size in inches cannot be established from PNG dimensions alone;
the tablet folders are responsive browser preview profiles, not hardware captures.

IMPORTANT — REPRESENTATION AND PLATFORM LIMITATIONS
These images are captured directly from Yere's existing shared responsive web UI
with fictional, browser-local demo data. They are NOT AI-generated interface
mockups, but they are also NOT captures from an installed Android release, a real
tablet, Android desktop runtime or Android XR headset/emulator. No native OS chrome,
permission dialogs, headset surroundings or spatial features have been fabricated.

Compare each set with the exact release and form factor you are distributing.
Do not assume that meeting image-size requirements proves platform support or
Play listing eligibility. Browser previews may differ in insets, fonts, keyboard,
native capabilities, WebView rendering or the UI in an older Android build.

XR CANDIDATES ARE NOT APPROVED XR SCREENSHOTS
The XR folder contains flat, dark-mode browser images with matching file dimensions
ONLY. It is a provisional format reference, NOT evidence of XR functionality or an
actual XR experience. Do not upload these as verified XR captures. First confirm
Yere is intended and eligible for that distribution category and capture/verify its
actual supported XR experience. These files do not establish immersive/spatial UI,
head tracking, hand input, controller support or any headset compatibility.
If XR is not part of your release, do not add XR assets simply to fill a section.

PRIVACY AND SAFETY
Only fictional sample reminders and a fictional Alex Morgan profile are used.
No real accounts, customer data, tokens or invitation secrets are included.
Capture sessions blocked external backend requests. No production data was written.
No APK/AAB was built. Cloud delivery, secure sharing, account sync, tablet/native
compatibility and XR compatibility were not tested by this screenshot task.

HOW TO USE
1. Extract this ZIP on your computer.
2. Compare images against the exact release on the appropriate supported device.
3. Upload only matching PNGs into the corresponding Play Console asset section.
4. Do not upload the README, manifest or ZIP itself into an image field.
5. Desktop and XR sets each contain four distinct screens, matching the screenshot
   count shown in the supplied requirements; platform validation remains separate.

Tablet/desktop/XR-format sets show workspace overview, upcoming reminders, calendar
and reminder notes/actions. The original phone set additionally includes recurring
reminders and dark theme. Workspace and calendar views can show a scrolled page.
Font: the app's Plus Jakarta Sans font, served locally during capture.
See manifest.json for pixel sizes, hashes, render profiles and verification limits.
